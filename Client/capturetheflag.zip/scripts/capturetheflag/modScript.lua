load("capturetheflag")
registerCoreModule("capturetheflag")